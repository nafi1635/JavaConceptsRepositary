public class mainaccount
	{
		public static void main(String args[])
		{
			account t=new account("smart",500);
			t.deposit();
			t.withdraw();

		        
	      	
	      	
	}	
	}
	
