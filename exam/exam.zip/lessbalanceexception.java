public class lessbalanceexception extends Exception
{
	public String toString()
		{
		return "There is insuffiecient balance";
		
		}
}		
