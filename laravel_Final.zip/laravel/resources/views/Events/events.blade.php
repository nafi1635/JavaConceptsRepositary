@extends(Auth::user() ? 'layouts.aftermain' : 'layouts.main')

@section('body')
   
     <div id="portfoliowrap">
        <h3>Events</h3>

        <div class="portfolio-centered">
            <div class="recentitems portfolio">
                <div class="portfolio-item graphic-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_09.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Tech fest</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_09.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                            
                <div class="portfolio-item web-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_02.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Alumni</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_02.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
        
                <div class="portfolio-item graphic-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_03.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Tech fest</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_03.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
        
                <div class="portfolio-item graphic-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_04.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Tech fest</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_04.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                                        
                <div class="portfolio-item books">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_05.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Convocation</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_05.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                                        
                <div class="portfolio-item graphic-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_06.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Tech fest</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_06.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                    
                <div class="portfolio-item books">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_04.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Convocation</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_07.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                    
                <div class="portfolio-item graphic-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_07.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Tech fest</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_08.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                                        
                <div class="portfolio-item web-design">
                    <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_01.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Alumni</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_01.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
    
            <div class="portfolio-item books">
                <div class="he-wrap tpl6">
                    <img src="assets/img/portfolio/portfolio_10.jpg" alt="">
                        <div class="he-view">
                            <div class="bg a0" data-animate="fadeIn">
                                <h3 class="a1" data-animate="fadeInDown">Convocation</h3>
                                <a data-rel="prettyPhoto" href="assets/img/portfolio/portfolio_10.jpg" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>
                                <a href="event-details" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                            </div><!-- he bg -->
                        </div><!-- he view -->      
                    </div><!-- he wrap -->
                </div><!-- end col-12 -->
                    
            </div><!-- portfolio -->
        </div><!-- portfolio container -->
     </div><!--/Portfoliowrap -->
@endsection