 <header id="header">
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-4">
                        
                    </div>
                    <div class="col-sm-6 col-xs-8">
                       <div class="social">
                            <ul class="social-share">
                                <li class="social-fb"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li class="social-lnk"><a href="#"><i class="fa fa-linkedin"></i></a></li> 
                                <li class="social-gog"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                 <li class="social-git"><a href="#"><i class="fa fa-github"></i></a></li>
                            </ul>
                            <div class="search">
                                <form role="form">
                                    <input type="text" class="search-form" autocomplete="off" placeholder="Search">
                                    <i class="fa fa-search"></i>
                                </form>
                           </div>
                       </div>
                    </div>

                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner" data-spy="affix" data-offset-top="25">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="test.html"><img src="images/logo.png" alt="logo"></a>
                </div>
                
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="/">Home</a></li>
                        <li><a href="test.html">About Us</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Connect <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="test.html">Alumni</a></li>
                                <li><a href="test.html">Faculty</a></li>
                                <li><a href="test.html">Students</a></li>
                            </ul>
                        </li>
                        <li><a href="/events">Events</a></li>
                        
                        <li><a href="test.html">Gallery</a></li> 
                        <li><a href="test.html">News</a></li> 
                        <li><a href="/contact-us">Contact Us</a></li>
                        <li><a id="modal_trigger" href="/login">Login</a></li>                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
        
</header><!--/header-->